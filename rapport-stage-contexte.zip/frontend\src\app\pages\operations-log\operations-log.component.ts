import { Component } from '@angular/core';

@Component({
  selector: 'app-operations-log',
  templateUrl: './operations-log.component.html',
  styleUrls: ['./operations-log.component.scss']
})
export class OperationsLogComponent {
}
